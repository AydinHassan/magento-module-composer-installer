<?php
/**
 * PHP Unit test suite for Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category   EcomDev
 * @package    EcomDev_PHPUnit
 * @copyright  Copyright (c) 2013 EcomDev BV (http://www.ecomdev.org)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 * @author     Ivan Chepurnyi <ivan.chepurnyi@ecomdev.org>
 */

/**
 * Layout configuration constraint
 *
 */
class EcomDev_PHPUnit_Constraint_Config_Layout
    extends EcomDev_PHPUnit_Constraint_AbstractConfig
{
    const XML_PATH_LAYOUT = '%s/layout/updates';

    const TYPE_LAYOUT_DEFINITION = 'layout_definition';
    const TYPE_LAYOUT_FILE = 'layout_file';

    /**
     * Design area (frontend, adminhtml)
     *
     * @var string
     */
    protected $_area = null;

    /**
     * Name of layout update,
     * if specified, constraint
     * will be additionally checked by this parameter
     *
     * @var string
     */
    protected $_layoutUpdate = null;

    /**
     * Restriction by theme name
     *
     * @var string
     */
    protected $_theme = null;

    /**
     * Restriction by design package name
     *
     * @var string
     */
    protected $_designPackage = null;

    /**
     * Model for assertion of the data
     *
     * @var EcomDev_PHPUnit_Constraint_Config_Design_PackageInterface
     */
    protected static $_designPackageModel = null;

    /**
     * Configuration constraint for cheking the existance of
     * layout file in configuration and a particular theme as well
     *
     * @param string $area design area (frontend|adminhtml)
     * @param string $expectedFile layout file name that should be checked
     * @param string $type type of assertion
     * @param string|null $layoutUpdate additional check for layout update name for assertion of configuration
     * @param string|null $theme additional check for layout file existance in a particular theme
     * @param string|null $designPackage additional check for layout file existance in a particular theme
     */
    public function __construct($area, $expectedFile, $type, $layoutUpdate = null,
        $theme = null, $designPackage = null)
    {
        $this->_area = $area;
        $this->_layoutUpdate = $layoutUpdate;
        $this->_designPackage = $designPackage;
        $this->_theme = $theme;

        $this->_expectedValueValidation += array(
            self::TYPE_LAYOUT_FILE => array(true, 'is_string', 'string'),
            self::TYPE_LAYOUT_DEFINITION => array(true, 'is_string', 'string')
        );

        $this->_typesWithDiff[] = self::TYPE_LAYOUT_FILE;
        $this->_typesWithDiff[] = self::TYPE_LAYOUT_DEFINITION;

        $nodePath = sprintf(self::XML_PATH_LAYOUT, $area);

        parent::__construct($nodePath, $type, $expectedFile);
    }

    /**
     * Sets design package model for assertions
     *
     * @param EcomDev_PHPUnit_Design_PackageInterface $model
     */
    public static function setDesignPackageModel(EcomDev_PHPUnit_Design_PackageInterface $model)
    {
        self::$_designPackageModel = $model;
    }

    /**
     * Retrieves design package model that was set before
     *
     * @return EcomDev_PHPUnit_Design_PackageInterface
     */
    public static function getDesignPackageModel()
    {
        return self::$_designPackageModel;
    }

    /**
     * Checks layout definititions for expected file defined in the configuration
     *
     * @param Varien_Simplexml_Element $other
     * @return boolean
     */
    protected function evaluateLayoutDefinition($other)
    {
        foreach ($other->children() as $layoutUpdate) {
            if ((string)$layoutUpdate->file === $this->_expectedValue
                && ($this->_layoutUpdate === null || $this->_layoutUpdate === $layoutUpdate->getName())) {
                return true;
            }
        }

        if ($this->_layoutUpdate === null) {
            $this->_layoutUpdate = 'your_module';
        }

        $expected = clone $other;
        $expected->addChild($this->_layoutUpdate)
            ->addChild('file', htmlspecialchars($this->_expectedValue));

        return $this->compareValues(
            $this->getXmlAsDom($expected),
            $this->getXmlAsDom($other)
        );
    }

    /**
     * Layout defition assertion text
     *
     * @return string
     */
    protected function textLayoutDefinition()
    {
        $text = sprintf('file "%s" is defined in configuration for %s area', $this->_expectedValue, $this->_area);

        if ($this->_layoutUpdate !== null) {
            $text .= sprintf(' in "%s" layout update', $this->_layoutUpdate);
        }

        return $text;
    }

    /**
     * Evaluates layout file existance
     *
     * @return boolean
     */
    protected function evaluateLayoutFile()
    {
        $assertion = self::getDesignPackageModel()
            ->getLayoutFileAssertion($this->_expectedValue, $this->_area, $this->_designPackage, $this->_theme);

        $this->setActualValue($assertion['actual']);
        $this->_expectedValue = $assertion['expected'];
        return $this->compareValues($assertion['expected'], $assertion['actual']);
    }

    /**
     * Text representation of layout file existance constraint
     *
     * @return string
     */
    protected function textLayoutFile()
    {
        return 'file is the same as expected and exists';
    }

    /**
     * Custom failure description for showing config related errors
     * (non-PHPdoc)
     * @see PHPUnit_Framework_Constraint::customFailureDescription()
     */
    protected function customFailureDescription($other)
    {
        return sprintf(
            'layout %s.',
            $this->toString()
        );
    }
}
